"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Sun,
  Zap,
  Thermometer,
  Droplets,
  Wind,
  Gauge,
  AlertTriangle,
  TrendingUp,
  BarChart3,
  Settings,
} from "lucide-react"

interface PanelData {
  temperature: number
  irradiance: number
  humidity: number
  panel_age: number
  maintenance_count: number
  soiling_ratio: number
  voltage: number
  current: number
  module_temperature: number
  cloud_coverage: number
  wind_speed: number
  pressure: number
  string_id: string
  error_code: string
  installation_type: string
}

interface PredictionResult {
  efficiency: number
  confidence: number
  recommendations: string[]
  risk_level: "low" | "medium" | "high"
}

export default function SolarPanelDashboard() {
  const [panelData, setPanelData] = useState<PanelData>({
    temperature: 25,
    irradiance: 800,
    humidity: 60,
    panel_age: 5,
    maintenance_count: 2,
    soiling_ratio: 0.1,
    voltage: 30,
    current: 8,
    module_temperature: 35,
    cloud_coverage: 20,
    wind_speed: 3,
    pressure: 1013,
    string_id: "A1",
    error_code: "E00",
    installation_type: "fixed",
  })

  const [prediction, setPrediction] = useState<PredictionResult | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleInputChange = (field: keyof PanelData, value: string | number) => {
    setPanelData((prev) => ({
      ...prev,
      [field]: typeof value === "string" ? value : Number(value),
    }))
  }

  const simulatePrediction = async () => {
    setIsLoading(true)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Mock prediction based on input values
    const baseEfficiency = 0.85
    const ageDegrade = Math.max(0, panelData.panel_age * 0.008)
    const soilingImpact = panelData.soiling_ratio * 0.15
    const tempImpact = Math.abs(panelData.module_temperature - 25) * 0.004
    const irradianceBoost = Math.min(0.1, (panelData.irradiance - 600) / 4000)

    const efficiency = Math.max(
      0.3,
      Math.min(0.95, baseEfficiency - ageDegrade - soilingImpact - tempImpact + irradianceBoost),
    )

    const confidence = Math.random() * 0.15 + 0.85

    let risk_level: "low" | "medium" | "high" = "low"
    const recommendations: string[] = []

    if (efficiency < 0.6) {
      risk_level = "high"
      recommendations.push("Immediate maintenance required")
      recommendations.push("Check for physical damage or severe soiling")
    } else if (efficiency < 0.75) {
      risk_level = "medium"
      recommendations.push("Schedule maintenance within 2 weeks")
      if (panelData.soiling_ratio > 0.15) recommendations.push("Clean panel surface")
    } else {
      risk_level = "low"
      recommendations.push("Panel operating within normal parameters")
    }

    if (panelData.panel_age > 15) {
      recommendations.push("Consider panel replacement evaluation")
    }

    if (panelData.soiling_ratio > 0.2) {
      recommendations.push("Increase cleaning frequency")
    }

    setPrediction({
      efficiency,
      confidence,
      recommendations,
      risk_level,
    })

    setIsLoading(false)
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "low":
        return "text-green-600 bg-green-50 border-green-200"
      case "medium":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "high":
        return "text-red-600 bg-red-50 border-red-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  const getEfficiencyColor = (efficiency: number) => {
    if (efficiency >= 0.8) return "text-green-600"
    if (efficiency >= 0.6) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sun className="h-8 w-8 text-yellow-500" />
            <h1 className="text-3xl font-bold text-gray-900">Solar Panel Efficiency Predictor</h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Advanced ML-powered system for predicting solar panel performance degradation and optimizing energy output
          </p>
        </div>

        <Tabs defaultValue="prediction" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="prediction" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Prediction
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="prediction" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Input Panel */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Panel Parameters
                  </CardTitle>
                  <CardDescription>Enter the current solar panel and environmental conditions</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="temperature" className="flex items-center gap-2">
                        <Thermometer className="h-4 w-4" />
                        Temperature (°C)
                      </Label>
                      <Input
                        id="temperature"
                        type="number"
                        value={panelData.temperature}
                        onChange={(e) => handleInputChange("temperature", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="irradiance" className="flex items-center gap-2">
                        <Sun className="h-4 w-4" />
                        Irradiance (W/m²)
                      </Label>
                      <Input
                        id="irradiance"
                        type="number"
                        value={panelData.irradiance}
                        onChange={(e) => handleInputChange("irradiance", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="humidity" className="flex items-center gap-2">
                        <Droplets className="h-4 w-4" />
                        Humidity (%)
                      </Label>
                      <Input
                        id="humidity"
                        type="number"
                        value={panelData.humidity}
                        onChange={(e) => handleInputChange("humidity", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="wind_speed" className="flex items-center gap-2">
                        <Wind className="h-4 w-4" />
                        Wind Speed (m/s)
                      </Label>
                      <Input
                        id="wind_speed"
                        type="number"
                        value={panelData.wind_speed}
                        onChange={(e) => handleInputChange("wind_speed", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="panel_age">Panel Age (years)</Label>
                      <Input
                        id="panel_age"
                        type="number"
                        value={panelData.panel_age}
                        onChange={(e) => handleInputChange("panel_age", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="soiling_ratio">Soiling Ratio (0-1)</Label>
                      <Input
                        id="soiling_ratio"
                        type="number"
                        step="0.01"
                        min="0"
                        max="1"
                        value={panelData.soiling_ratio}
                        onChange={(e) => handleInputChange("soiling_ratio", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="voltage">Voltage (V)</Label>
                      <Input
                        id="voltage"
                        type="number"
                        value={panelData.voltage}
                        onChange={(e) => handleInputChange("voltage", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="current">Current (A)</Label>
                      <Input
                        id="current"
                        type="number"
                        value={panelData.current}
                        onChange={(e) => handleInputChange("current", e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="installation_type">Installation Type</Label>
                      <Select
                        value={panelData.installation_type}
                        onValueChange={(value) => handleInputChange("installation_type", value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fixed">Fixed</SelectItem>
                          <SelectItem value="tracking">Single-axis Tracking</SelectItem>
                          <SelectItem value="dual-axis">Dual-axis Tracking</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="error_code">Error Code</Label>
                      <Select
                        value={panelData.error_code}
                        onValueChange={(value) => handleInputChange("error_code", value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="E00">E00 - No Error</SelectItem>
                          <SelectItem value="E01">E01 - Minor Issue</SelectItem>
                          <SelectItem value="E02">E02 - Moderate Issue</SelectItem>
                          <SelectItem value="E03">E03 - Major Issue</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button onClick={simulatePrediction} disabled={isLoading} className="w-full" size="lg">
                    {isLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Gauge className="h-4 w-4 mr-2" />
                        Predict Efficiency
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Results Panel */}
              <div className="space-y-6">
                {prediction && (
                  <>
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <TrendingUp className="h-5 w-5" />
                          Efficiency Prediction
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="text-center space-y-2">
                          <div className={`text-4xl font-bold ${getEfficiencyColor(prediction.efficiency)}`}>
                            {(prediction.efficiency * 100).toFixed(1)}%
                          </div>
                          <div className="text-sm text-gray-600">Predicted Efficiency</div>
                          <Progress value={prediction.efficiency * 100} className="w-full h-3" />
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Confidence:</span>
                          <span className="font-medium">{(prediction.confidence * 100).toFixed(1)}%</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-600">Risk Level:</span>
                          <Badge className={getRiskColor(prediction.risk_level)}>
                            {prediction.risk_level.toUpperCase()}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <AlertTriangle className="h-5 w-5" />
                          Recommendations
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {prediction.recommendations.map((rec, index) => (
                            <Alert key={index}>
                              <AlertDescription>{rec}</AlertDescription>
                            </Alert>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </>
                )}

                {!prediction && (
                  <Card>
                    <CardContent className="flex items-center justify-center h-64 text-gray-500">
                      <div className="text-center space-y-2">
                        <Gauge className="h-12 w-12 mx-auto opacity-50" />
                        <p>Enter panel parameters and click "Predict Efficiency" to see results</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="analytics">
            <Card>
              <CardHeader>
                <CardTitle>Performance Analytics</CardTitle>
                <CardDescription>Historical trends and insights</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-gray-500">
                  <BarChart3 className="h-12 w-12 mx-auto opacity-50 mb-4" />
                  <p>Analytics dashboard coming soon...</p>
                  <p className="text-sm">
                    This will show historical performance trends, comparative analysis, and predictive insights.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Model Settings</CardTitle>
                <CardDescription>Configure prediction parameters and thresholds</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-gray-500">
                  <Settings className="h-12 w-12 mx-auto opacity-50 mb-4" />
                  <p>Settings panel coming soon...</p>
                  <p className="text-sm">
                    This will allow you to adjust model parameters, set alert thresholds, and configure data sources.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
